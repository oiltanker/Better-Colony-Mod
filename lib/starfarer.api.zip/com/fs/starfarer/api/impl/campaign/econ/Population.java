package com.fs.starfarer.api.impl.campaign.econ;


public class Population extends BaseMarketConditionPlugin {
	
	public Population() {
		
	}
	
	public void apply(String id) {
	}

	public void unapply(String id) {
	
	}

}
