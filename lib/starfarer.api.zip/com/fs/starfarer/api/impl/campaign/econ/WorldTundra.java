package com.fs.starfarer.api.impl.campaign.econ;


public class WorldTundra extends WorldFarming {

	public WorldTundra() {
		super(ConditionData.WORLD_TUNDRA_FARMING_MULT, ConditionData.WORLD_TUNDRA_MACHINERY_MULT);
	}

}
