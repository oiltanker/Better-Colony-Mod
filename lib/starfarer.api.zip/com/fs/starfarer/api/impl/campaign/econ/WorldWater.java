package com.fs.starfarer.api.impl.campaign.econ;



public class WorldWater extends WorldFarming {

	public WorldWater() {
		super(ConditionData.WORLD_WATER_FARMING_MULT, ConditionData.WORLD_WATER_MACHINERY_MULT, ConditionData.WORLD_WATER_MAX_FOOD);
	}
}
