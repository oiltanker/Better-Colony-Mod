package com.fs.starfarer.api.campaign;

public interface SectorGenProgress {
	void render(String text, float progress);
}
