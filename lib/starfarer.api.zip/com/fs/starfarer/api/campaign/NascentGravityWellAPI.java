package com.fs.starfarer.api.campaign;


public interface NascentGravityWellAPI extends SectorEntityToken {

	PlanetAPI getPlanet();

}
