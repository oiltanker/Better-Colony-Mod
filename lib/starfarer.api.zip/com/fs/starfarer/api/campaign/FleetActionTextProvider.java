package com.fs.starfarer.api.campaign;


public interface FleetActionTextProvider {
	String getActionText(CampaignFleetAPI fleet);
}
