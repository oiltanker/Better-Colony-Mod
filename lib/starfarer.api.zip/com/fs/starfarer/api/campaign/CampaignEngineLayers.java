package com.fs.starfarer.api.campaign;


public enum CampaignEngineLayers {
	TERRAIN_1,
	TERRAIN_2,
	PLANETS,
	TERRAIN_3,
	RINGS,
	TERRAIN_4,
	ASTEROIDS,
	TERRAIN_5,
	JUMP_POINTS,
	TERRAIN_6,
	TERRAIN_6A,
	TERRAIN_6B,
	STATIONS,
	TERRAIN_7,
	//JUMP_POINTS,
	TERRAIN_7A,
	FLEETS,
	TERRAIN_8,
	TERRAIN_9,
	TERRAIN_10,
	ABOVE,
}
