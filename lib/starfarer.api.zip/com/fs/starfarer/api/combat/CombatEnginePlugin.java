package com.fs.starfarer.api.combat;


/**
 * @author Alex Mosolov
 *
 * Copyright 2012 Fractal Softworks, LLC
 */
public interface CombatEnginePlugin {
	public void init(CombatEngineAPI engine);
}
