package com.fs.starfarer.api.combat;

import java.util.List;

import com.fs.starfarer.api.input.InputEventAPI;

public class BaseEveryFrameCombatPlugin implements EveryFrameCombatPlugin {

	public void advance(float amount, List<InputEventAPI> events) {
	}

	public void renderInUICoords(ViewportAPI viewport) {
	}

	public void init(CombatEngineAPI engine) {
		
	}

	public void renderInWorldCoords(ViewportAPI viewport) {
		
	}

	public void processInputPreCoreControls(float amount, List<InputEventAPI> events) {
		
	}

}
